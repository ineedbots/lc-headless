import json
import pathlib

live=pathlib.Path(__file__).resolve().parent
dest=live/'batch5'
(dest/'accounts').mkdir(parents=True,exist_ok=True)
client=json.loads((live/'batch3/client.json').read_text())
client['client']['logFile']=str(dest/'client.log')
client['scripting']['accountsDirectory']=str(dest/'accounts')
client['scripting']['progressDirectory']=str(dest/'progress')
client['http']['port']=18365
(dest/'client.json').write_text(json.dumps(client,indent=2))
for name in ['thiever','ardy_thiever','aio_teleport']:
    account=json.loads((live/f'batch3/accounts/{name}.jsonc').read_text())
    account['randomEvents']=True
    if name=='aio_teleport': account['script']['settings']['AIO Teleport']['law_batch_size']=10
    (dest/f'accounts/{name}.jsonc').write_text(json.dumps(account,indent=2))
