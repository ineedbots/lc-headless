import json
import pathlib
import shutil
import subprocess

ROOT = pathlib.Path.cwd()
LIVE = ROOT / 'build/issue36'
ENGINE = ROOT.parent / '289server/engine'
WEST = [3185, 3440, 0]
SEERS = [2725, 3491, 0]
cases = []

def add(file, tile=WEST, bank=None, pack=None, settings=None, vars=None, worn=None, bank_required=True, label=None):
    text = (ROOT / f'scripts/bots/{file}.py').read_text(encoding='utf-8')
    import re
    match = re.search(r"BOT = define_bot\(\s*name='([^']+)'", text)
    name = match[1] if match else 'WalkTo'
    cases.append(dict(key=label or file, file=file, bot=name, tile=tile, bank=bank or [], pack=pack or [], settings=settings or {}, vars=vars or {}, worn=worn or [], bank_required=bank_required))

add('cook_bot', [2809,3441,0], [['Raw salmon',5000]])
add('dart_fletcher', pack=[['Bronze dart tip',200000],['Feather',200000]], bank_required=False, vars={'desertrescue':30})
add('firemaker', [3253,3420,0], [['Logs',5000],['Tinderbox',1]])
add('flax_aio', SEERS)
add('flax_picker', SEERS)
add('flax_spinner', SEERS, [['Flax',5000]])
add('gem_cutter', bank=[['Uncut sapphire',5000],['Chisel',1]])
add('gnome_magic_chopper', [2445,3425,1], [['Rune axe',1],['Knife',1]], pack=[['Magic logs',26]], settings={'fletch_logs':False})
add('herb_cleaner', bank=[[199,5000]])
add('herblore_secondaries', bank=[['Unicorn horn',5000],['Pestle and mortar',1]], settings={'secondary':'Unicorn horn dust'})
add('jive_balls', [3093,3243,0], [['Shears',1]], settings={'location':'lumbridge'})
add('jive_caskets', bank=[[405,5000]])
add('jive_crafting', [3269,3167,0], [['Gold bar',5000],['Sapphire',5000],['Ring mould',1]])
add('jive_enchanter', bank=[['Sapphire ring',5000],['Cosmic rune',10000],['Water rune',10000]])
add('leather_crafter', bank=[['Leather',5000],['Needle',1],['Thread',50000]])
add('nature_crafter', [3013,3355,0], [['Rune essence',10000]], pack=[['Air talisman',1]], settings={'rune':'Air runes','mode':'Master','partner':'p36runner','bank_every':2}, label='nature_master')
add('nature_crafter', [3013,3355,0], [['Air talisman',1],['Rune essence',10000]], settings={'rune':'Air runes','mode':'Runner','partner':'p36master'}, label='nature_runner')
add('potion_maker', bank=[['Guam leaf',5000],['Vial of water',5000],['Eye of newt',5000]])
add('rune_crafter', [3013,3355,0], [['Air talisman',1],['Rune essence',10000]])
add('coal_trucks', SEERS, [['Rune pickaxe',1]], vars={'coal_truck':100})
add('smelter_bot', [3269,3167,0], [['Copper ore',5000],['Tin ore',5000]])
add('smithing_bot', bank=[['Bronze bar',5000],['Hammer',1]])
add('superheater', bank=[['Staff of fire',1],['Copper ore',5000],['Tin ore',5000],['Nature rune',10000],['Fire rune',50000]], settings={'goldsmith_gauntlets':False})
add('tanner_bot', [3269,3167,0], [['Cowhide',5000]], settings={'buy_thread':False})
add('vial_filler', [2946,3369,0], [['Vial',5000]])
add('climbing_boots', [2946,3369,0], [['Law rune',10000],['Air rune',30000],['Water rune',10000]], vars={'death_equiproom':80,'death_map':8})
add('bone_burier', bank=[[526,10000]])
add('bank_fletcher', bank=[['Logs',5000],['Bow string',5000],['Knife',1]], settings={'mode':'cut+string','product':'Long bow'})
add('woodcutter', SEERS, [['Rune axe',1]], settings={'location':'Seers Oaks','tree_name':'Oak'})
add('woodcutter', SEERS, [['Rune axe',1],['Tinderbox',1]], settings={'location':'Seers Oaks','tree_name':'Oak','burn_mode':'Chop then burn'}, label='chop_burn')
add('fisher', [2809,3441,0], [['Big fishing net',1]], settings={'location':'Catherby','fish_method':'Big net — mackerel/cod/bass','cook_mode':'Cook then bank'})
add('miner', bank=[['Rune pickaxe',1]], settings={'location':'Southeast Varrock Mine','rocks':['Copper','Tin']})
add('gnome_course', [2474,3438,0], bank_required=False)
add('wildy_agility', [3094,3493,0], settings={'food':'Lobster'})
add('edgeville_monkey_bars', [3094,3493,0], settings={'restock_mode':'Dungeon ladder (out of food)'})
add('brimhaven_agility', [2655,3283,0], settings={'bank_at_tickets':3})
add('thiever', [3094,3493,0], settings={'target':'Man','food':'Lobster','banking':'Auto'})
add('ardy_cakes', [2655,3283,0], settings={'solve_clues':False})
add('ardy_thiever', [2655,3283,0], settings={'solve_clues':False,'bank_at_loot_slots':2})
gear = [[3,1333],[4,1127],[7,1079],[0,1163],[5,1201]]
add('ardy_fighter', [2655,3283,0], settings={'solve_clues':False,'bank_at_loot_slots':2}, worn=gear)
add('walk_to', [3222,3218,0], settings={'destination':'Falador'}, bank_required=False)
add('door_opener', [3215,3212,0], bank_required=False)
add('aio_teleport', bank=[['Law rune',10000],['Air rune',50000],['Fire rune',10000]], settings={'teleport_name':'varrock','use_staff_runes':False})
add('chaos_druid_killer', [3094,3493,0], worn=gear)
add('hill_giant', pack=[['Brass key',1]], worn=gear, settings={'loot_slots':2})

for i, case in enumerate(cases):
    case['username'] = {'nature_master':'p36master','nature_runner':'p36runner'}.get(case['key'],f'p36b{i:02}')
    case['batch'] = i // 12
    case['bank'] = [[995,2000000],[379,2000]] + case['bank']

LIVE.mkdir(parents=True, exist_ok=True)
(LIVE / 'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
for folder in ['engine/data/config','engine/data/players','progress']:
    (LIVE / folder).mkdir(parents=True,exist_ok=True)
for asset in ['data/pack','data/raw','public','view']:
    link = LIVE / 'engine' / asset
    if not link.exists():
        subprocess.run(['cmd','/c','mklink','/J',str(link),str(ENGINE / asset)],check=True,capture_output=True)
for key in ['private.pem','public.pem']:
    shutil.copyfile(ENGINE / 'data/config' / key,LIVE / 'engine/data/config' / key)
world = json.loads((ROOT / 'build/issue37/engine/data/config/world.json').read_text(encoding='utf-8-sig'))
world['web'].update(port=18036,managementPort=18039)
world['node'].update(port=19336,profile='issue36accept',rateLimitAddressLogin=200,rateLimitDeviceLogin=200)
(LIVE / 'engine/data/config/world.json').write_text(json.dumps(world,indent=2))
for batch in range(4):
    dest = LIVE / f'batch{batch}'
    (dest / 'accounts').mkdir(parents=True,exist_ok=True)
    client = json.loads((ROOT / 'build/issue37/client.json').read_text(encoding='utf-8-sig'))
    client['server']['port']=19336
    client['client']['logFile']=str(dest / 'client.log')
    client['scripting'].update(accountsDirectory=str(dest/'accounts'),scriptsDirectory=str(LIVE/'scripts'),progressDirectory=str(dest/'progress'),callTimeoutMs=5000,loginIntervalSeconds=1,connectAttempts=0)
    client['http']={'host':'127.0.0.1','port':18360+batch}
    (dest/'client.json').write_text(json.dumps(client,indent=2))
    for case in cases:
        if case['batch']!=batch: continue
        file = 'walk_acceptance.py' if case['file']=='walk_to' else f"bots/{case['file']}.py"
        account=dict(username=case['username'],password='scratch36',randomEvents=False,stallMinutes=0,script=dict(file=file,progressReportMinutes=1,settings={case['bot']:case['settings']}))
        (dest / 'accounts' / (case['key']+'.jsonc')).write_text(json.dumps(account,indent=2))
print(f'Prepared {len(cases)} cases in four client processes')
