import collections
import datetime
import json
import pathlib
import re

LIVE = pathlib.Path(__file__).resolve().parent
cases = json.loads((LIVE/'cases.json').read_text())
cutoffs=json.loads((LIVE/'cutoffs.json').read_text()) if (LIVE/'cutoffs.json').exists() else {}
events = collections.defaultdict(list)
for line in (LIVE/'server.stdout.log').read_text(encoding='utf-8',errors='replace').splitlines():
    if not line.startswith('ISSUE36 '): continue
    _,kind,payload=line.split(' ',2)
    try: row=json.loads(payload)
    except json.JSONDecodeError: continue
    row['kind']=kind
    events[row.get('account','server')].append(row)
results=[]
for case in cases:
    rows=events[case['username']]
    seed=next((r for r in rows if r['kind']=='SEED'),None)
    text=(LIVE/f"batch{case['batch']}/client.log").read_text(encoding='utf-8',errors='replace')
    logs=[l for l in text.splitlines() if f"[{case['key']}]" in l]
    starts=[l for l in logs if 'Logged in (' in l]
    start=datetime.datetime.fromisoformat(starts[-1].split()[0]).timestamp()*1000+1000 if starts else None
    if case['key']=='cook_bot' and case['batch']==4:
        returned=[l for l in logs if 'random event: mime solved' in l]
        start=datetime.datetime.fromisoformat(returned[0].split()[0]).timestamp()*1000+1000 if returned else None
    cutoff=cutoffs.get(str(case['batch']),float('inf'))
    samples=[r for r in rows if r['kind']=='SAMPLE' and start and start<=r['at']<=cutoff]
    bank=[r for r in rows if r['kind']=='BANK' and start and start<=r['at']<=cutoff]
    end=samples[-1]['at'] if samples else None
    seconds=(end-start)/1000 if start and end else 0
    measured_logs=[l for l in logs if datetime.datetime.fromisoformat(l.split()[0]).timestamp()*1000<=cutoff]
    errors=[l for l in measured_logs if 'ERROR' in l]
    stopped=[l for l in measured_logs if 'script stopped itself' in l]
    progress=[l.split('Progress: ',1)[1] for l in measured_logs if 'Progress: ' in l]
    deltas={str(i):round((samples[-1]['xp'][i]-samples[0]['xp'][i])/10,1) for i in range(21) if len(samples)>1 and samples[-1]['xp'][i]!=samples[0]['xp'][i]}
    result=dict(key=case['key'],bot=case['bot'],username=case['username'],start=start,end=end,seconds=round(seconds,1),sample_count=len(samples),bank_adds=len([r for r in bank if r['method']=='invAdd']),bank_withdraws=len([r for r in bank if r['method']=='invDel']),xp_delta=deltas,progress=progress[-1] if progress else None,errors=errors,stopped=stopped,tile=samples[-1]['tile'] if samples else None)
    result['duration_ok']=seconds>=900 and not errors and not stopped
    result['bank_ok']=not case['bank_required'] or len(bank)>0
    results.append(result)
(LIVE/'results.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:
    print(f"{r['key']:24} {r['seconds']/60:5.1f}m bank+{r['bank_adds']:3}/-{r['bank_withdraws']:3} errors={len(r['errors'])} stop={len(r['stopped'])} {r['progress'] or r['tile']}")
