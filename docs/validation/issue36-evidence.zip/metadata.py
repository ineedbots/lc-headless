import hashlib
import json
import pathlib
import subprocess

root=pathlib.Path.cwd()
engine=root.parent/'289server/engine'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def revision(path):
    return subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
record=dict(client_base=revision(root),engine=revision(engine),content=revision(root.parent/'289server/content'),tick_ms=600,xp_rate=1,executable_sha256=sha(root/'build/windows-msvc/Release/Rs2004Headless.exe'),source={str(p.relative_to(root)).replace('\\','/'):sha(p) for p in (root/'scripts').rglob('*.py')},packed_server={p.name:sha(p) for p in (engine/'data/pack/server').glob('*') if p.is_file()},changes=subprocess.check_output(['git','diff','--','scripts','tests'],text=True))
(root/'build/issue36/environment.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
