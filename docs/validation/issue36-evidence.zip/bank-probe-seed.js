(()=>{
    const world=globalThis.issue36World;
    const inv=globalThis.issue36InvType.getId('inv');
    const changes=[];
    for(const p of world.players) {
        if(!p) continue;
        if(p.username==='p36b36') {
            const count=p.getInventory(inv).freeSlotCount;
            changes.push({account:p.username,id:440,count:p.invAdd(inv,440,count),reason:'Fill free pack slots with iron ore to exercise Auto food-bank deposit'});
        }
        if(p.username==='p36b38') changes.push({account:p.username,id:562,count:p.invAdd(inv,562,1),reason:'Second loot stack crosses configured two-slot banking threshold'});
        if(p.username==='p36b42') {
            const count=p.getInventory(inv).getItemCount(563);
            changes.push({account:p.username,id:563,count:-p.invDel(inv,563,count),reason:'Empty carried law runes before restarting the focused bank/restock check'});
        }
    }
    console.log('ISSUE36 BANK_PROBE_SEED',JSON.stringify({at:Date.now(),changes}));
    return changes;
})()
