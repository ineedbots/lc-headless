import json
import pathlib

live=pathlib.Path(__file__).resolve().parent
dest=live/'batch4'
(dest/'accounts').mkdir(parents=True,exist_ok=True)
client=json.loads((live/'batch0/client.json').read_text())
client['client']['logFile']=str(dest/'client.log')
client['scripting']['accountsDirectory']=str(dest/'accounts')
client['scripting']['progressDirectory']=str(dest/'progress')
client['http']['port']=18364
(dest/'client.json').write_text(json.dumps(client,indent=2))
account=json.loads((live/'batch0/accounts/cook_bot.jsonc').read_text())
account['randomEvents']=True
(dest/'accounts/cook_bot.jsonc').write_text(json.dumps(account,indent=2))
cases=json.loads((live/'cases.json').read_text())
cases[0]['batch']=4
cases[0]['randomEvents']=True
(live/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
