Complete phase-11's missing live-duration evidence against an isolated revision-289 world at 600 ms ticks / XP rate 1. The report covers all 43 listed bots through 45 scenarios, including NatureCrafter's two roles and GatheringBot chop-and-burn, with per-bot durations, bank evidence and raw logs/source snapshots.

Live discovery also fixes two blockers: FlaxPicker now travels when flax is visible outside its picking radius, and HerbloreSecondaries no longer passes an unrelated keyword to `min()` while grinding. Runtime regressions cover both behaviors.

Validation: Windows x64 Release build and full CTest passed; revision-289 real-cache checks passed; changed Python dialect lint and whitespace checks passed. Optional caches skip as documented. CookBot's guardian-disabled mime interruption is excluded and its corrected interval is measured after normal event recovery. Short focused banking checks are explicitly separate from endurance measurements; WalkTo repeats its ordinary task through existing composition/settings APIs. The false ChaosDruidKiller death counter is tracked in #134.

Resolves: #36
