JSON.stringify([...globalThis.issue36World.players].filter(p=>p && p.username.startsWith('p36')).map(p=>({account:p.username,tile:[p.x,p.z,p.level],hp:p.levels[3]})))
