import datetime
import json
import pathlib
import re
import time

live=pathlib.Path(__file__).resolve().parent
logs=(live/'batch5/client.log').read_text(encoding='utf-8')
end=int(time.time()*1000)
results=[]
for key,username in [('thiever','p36b36'),('ardy_thiever','p36b38'),('aio_teleport','p36b42')]:
    lines=[l for l in logs.splitlines() if f'[{key}]' in l]
    start_line=next(l for l in lines if 'Logged in (' in l)
    start=datetime.datetime.fromisoformat(start_line.split()[0]).timestamp()*1000+1000
    errors=[l for l in lines if 'ERROR' in l or 'script stopped itself' in l]
    bank=[]
    for line in (live/'server.stdout.log').read_text(encoding='utf-8').splitlines():
        if not line.startswith('ISSUE36 BANK '): continue
        row=json.loads(line.split(' ',2)[2])
        if row['account']==username and start<=row['at']<=end: bank.append(row)
    if not bank or errors: raise SystemExit(f'Bank probe incomplete for {key}: bank={bank}, errors={errors}')
    results.append(dict(key=key,username=username,start=start,end=end,seconds=round((end-start)/1000,1),deposits=[r for r in bank if r['method']=='invAdd'],withdrawals=[r for r in bank if r['method']=='invDel'],errors=errors))
(live/'bank-probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
print([(r['key'],len(r['deposits']),len(r['withdrawals'])) for r in results])
