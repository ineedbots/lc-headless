import datetime
import json
import pathlib
import subprocess
import sys
import time

live=pathlib.Path(__file__).resolve().parent
subprocess.run([sys.executable,'-X','utf8',str(live/'analyze.py')],check=True,stdout=subprocess.DEVNULL)
results=json.loads((live/'results.json').read_text())
cases=json.loads((live/'cases.json').read_text())
batches={int(value) for value in sys.argv[1:]}
for case,result in zip(cases,results):
    if case['batch'] in batches and not result['duration_ok']:
        raise SystemExit(f"Cannot freeze {case['key']}: {result['seconds']} seconds; errors={result['errors']}; stopped={result['stopped']}")
path=live/'cutoffs.json'
cutoffs=json.loads(path.read_text()) if path.exists() else {}
stamp=int(time.time()*1000)
for batch in batches:
    cutoffs[str(batch)]=stamp
path.write_text(json.dumps(cutoffs,indent=2)+'\n')
subprocess.run([sys.executable,'-X','utf8',str(live/'analyze.py')],check=True,stdout=subprocess.DEVNULL)
print('Froze batches',sorted(batches),'at',datetime.datetime.fromtimestamp(stamp/1000,datetime.UTC).isoformat())
