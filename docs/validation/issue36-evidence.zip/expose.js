this.players ? (()=>{
    globalThis.issue36World=this;
    globalThis.issue36InvType=InvType;
    const load=PlayerLoading.load;
    PlayerLoading.load=function(...args) {
        const p=load.apply(this,args);
        if(p.username==='p36b44') {
            p.invAdd(InvType.getId('bank'),333,2000);
            console.log('ISSUE36 FIXTURE_CORRECTION',JSON.stringify({at:Date.now(),account:p.username,id:333,count:2000,reason:'Stock default Trout before restarted run'}));
        }
        return p;
    };
    return {at:Date.now(),exposed:true,tick:this.currentTick};
})() : null
