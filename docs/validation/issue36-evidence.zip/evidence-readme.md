# Issue 36 raw evidence

Client/server source revisions, conditions, fixture corrections and the final
per-bot table are documented in `docs/design/Phase11LiveValidation.md`.

- `cases.json`: exact initial account settings, bank/pack/equipment stock and
  prerequisite vars for each of the 45 cases. User accounts were never loaded.
- `server.mts`: isolated engine bootstrap, initial seeding, 600 ms assertion,
  bank mutation/message logs and 30-second account samples.
- `server.stdout.log`: primary raw server transcript; `discovery-server.*` are
  earlier preparation attempts. Initial bank seeds precede each `SEED` record
  and are excluded from acceptance bank evidence.
- `batch*/client.log`: primary per-process client transcript; discovery logs
  and batch 3's pre-trout transcript are retained separately. All logs use UTC.
- `source/`: exact runnable bot snapshots and changed regression specs.
- `sanitized/batch*/accounts/`: exact account settings with passwords removed.
- `results.json`: latest measured interval, progress and observed bank actions;
  any focused checks after duration measurement are identified separately.
- `setup.py`: original local fixture generation script. Its baseline JSON comes
  from an earlier local scratch run; generated client JSON and cases.json are
  preserved here so that baseline is not needed to inspect/reconstruct settings.
  It uses Windows junctions to share cache/content read-only and never edits the
  original engine's configuration or player saves. Do not point it at real
  accounts. A rerun needs a new save profile to repeat the initial state.
- `scripts/walk_acceptance.py`: repeats ordinary WalkTo legs through documented
  bot composition/settings APIs, switching destinations only after arrival.
- `expose.js`, `inspect-paused.mjs`: brief debugger setup before batch 3's
  restarted interval; stocks HillGiant's actual default food (Trout). The failed
  dynamic-import attempt in stock-trout.js changed no state. snapshot.js is
  observational only. This is seeded behavioral acceptance, not a throughput
  benchmark or an untouched production-engine run.
- `release-tests.log`, `real-cache-tests.log`, `flax-regression.log`, `grind-regression.log`,
  `changed-python-lint.log`: local checks. Optional caches can skip as documented.
- `file-manifest.json`: SHA-256 and length of every other archive entry.

No private RSA key, player save, user credential, user account file or database
is included. Account JSON passwords are removed. The setup script contains only
the disposable scratch password, which is unnecessary to review the evidence.
Public RSA login settings in client JSON are not secret.
