## Observed behavior

During #36's revision-289 live acceptance, ChaosDruidKiller incremented its `Deaths` counter during an ordinary bank trip out of Edgeville dungeon. There was no script error; it banked, restocked and returned to fighting.

Client base: `68d39960a149948db7edd773b33185a894f734e3`; engine `278bd51cc17cc0d093e1ea3895536a8054583f97`; content `f32c62f66302f76b43c752ede3181de0c0d01369`. Normal 600 ms ticks / XP rate 1, seeded scratch account.

Relevant UTC log sequence on 2026-11-21:

```text
23:16:51.294 Progress: leaving the dungeon; Kills 18, Looted 17, Food 10, Banks 0, Deaths 0
23:17:20.487 climbing out via Ladder at Tile(3096, 9867, 0)
23:17:31.242 arrived (3 clicks)
23:17:40.242 surface respawn detected after leaving the dungeon unexpectedly — will bank for a fresh trip before returning
23:17:51.296 Progress: walking to the Edgeville trapdoor; Banks 2, Deaths 1
23:18:51.304 Progress: fighting Chaos druid; Banks 2, Deaths 1
```

## Likely cause

`scripts/bots/chaos_druid_killer.py`'s `observe_lifecycle()` calls `chaos_druid_respawned(previous, current, trip_prepared)`. That predicate treats any transition from `druid-dungeon` to `surface` while a trip is prepared as a death. A planned climb out for banking can satisfy the same predicate before the travel/banking workflow has reset its lifecycle state.

## Work and acceptance

- Distinguish planned surface exits from an actual respawn; preserve recovery for a genuine death with a missed chat message.
- Exercise the real banking/travel workflow in a runtime regression, including the lifecycle observation when it first reaches the surface.
- Replay a full dungeon-to-bank-to-dungeon cycle without incrementing `Deaths`, and retain the real-respawn regression.

Raw logs and source snapshots will be linked from #36's acceptance report. This diagnostic/redundant-restock finding does not invalidate that issue's script-error-free duration and banking observations.
