import hashlib
import json
import pathlib
import subprocess
import zipfile

ROOT=pathlib.Path.cwd()
LIVE=ROOT/'build/issue36'
out=ROOT/'docs/validation/issue36-evidence.zip'
out.parent.mkdir(parents=True,exist_ok=True)
files={}
for pattern in ['*.py','*.mjs','*.mts','*.js','*.json','*.log','*.md','*.txt','scripts/*.py','batch*/*.log','batch*/*.json']:
    for path in LIVE.glob(pattern):
        if path.is_file(): files[path.relative_to(LIVE).as_posix()]=path.read_bytes()
for path in LIVE.glob('batch*/accounts/*.jsonc'):
    account=json.loads(path.read_text(encoding='utf-8-sig'))
    account.pop('password',None)
    files['sanitized/'+path.relative_to(LIVE).as_posix()]=(json.dumps(account,indent=2)+'\n').encode()
for pattern in ['scripts/bots/*.py','scripts/bots/gathering/*.py','tests/Stdlib/rs2b0t/test_flax_picker_travel_runtime.py','tests/Stdlib/rs2b0t/test_herblore_secondaries_grind_runtime.py']:
    for path in ROOT.glob(pattern):
        files['source/'+path.relative_to(ROOT).as_posix()]=path.read_bytes()
files['source/changes.patch']=subprocess.check_output(['git','diff','--','scripts','tests'])
files['report.md']=(ROOT/'docs/design/Phase11LiveValidation.md').read_bytes()
manifest={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in files.items()}
files['file-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()): archive.writestr(name,data)
print(f'{out}: {out.stat().st_size:,} bytes, {len(files)} entries, SHA-256 {hashlib.sha256(out.read_bytes()).hexdigest()}')
