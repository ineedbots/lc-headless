import fs from 'node:fs';
const endpoints=await (await fetch('http://127.0.0.1:9236/json/list')).json();
const socket=new WebSocket(endpoints[0].webSocketDebuggerUrl);
await new Promise(resolve=>socket.addEventListener('open',resolve,{once:true}));
let id=0;
const pending=new Map();
const scripts=[];
let pausedResolve;
const paused=new Promise(resolve=>pausedResolve=resolve);
socket.addEventListener('message',event=>{
    const value=JSON.parse(event.data);
    if(value.method==='Debugger.scriptParsed') scripts.push(value.params);
    if(value.method==='Debugger.paused') pausedResolve(value.params);
    else if(value.id && pending.has(value.id)) { pending.get(value.id)(value); pending.delete(value.id); }
});
function send(method,params={}) {
    const key=++id;
    const result=new Promise(resolve=>pending.set(key,resolve));
    socket.send(JSON.stringify({id:key,method,params}));
    return result;
}
await send('Debugger.enable');
const worldScript=scripts.find(s=>s.url.replaceAll('\\','/').includes('/engine/World.ts'));
if(!worldScript) throw new Error('World script not found: '+JSON.stringify(scripts.map(s=>s.url).filter(u=>u.includes('World'))));
const source=await send('Debugger.getScriptSource',{scriptId:worldScript.scriptId});
const offset=source.result.scriptSource.indexOf('cycle(){');
if(offset<0) throw new Error('World cycle function not found');
const breakpoint=await send('Debugger.setBreakpoint',{location:{scriptId:worldScript.scriptId,lineNumber:0,columnNumber:offset+8}});
try {
    const info=await paused;
    console.log(JSON.stringify(info.callFrames.map(f=>({name:f.functionName,url:f.url,location:f.location}))));
    for(const frame of info.callFrames) {
        const expression=process.argv[2] ? fs.readFileSync(process.argv[2],'utf8') : "(typeof World !== 'undefined' && World.npcs ? World.npcs : this.npcs)?.filter(n=>n && n.x>2870 && n.x<2940 && n.z>9760 && n.z<9840).map(n=>({type:n.type,name:NpcType.get(n.type).name,tile:[n.x,n.z,n.level]}))";
        const value=await send('Debugger.evaluateOnCallFrame',{callFrameId:frame.callFrameId,expression,returnByValue:true});
        if(value.result?.result?.value) { console.log(JSON.stringify(value)); break; }
    }
} finally {
    if(breakpoint.result?.breakpointId) await send('Debugger.removeBreakpoint',{breakpointId:breakpoint.result.breakpointId});
    await send('Debugger.resume');
    socket.close();
}
