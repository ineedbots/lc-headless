import datetime
import json
import pathlib
import re
import subprocess
import sys

root=pathlib.Path.cwd()
live=root/'build/issue36'
subprocess.run([sys.executable,'-X','utf8',str(live/'analyze.py')],check=True,stdout=subprocess.DEVNULL)
cases=json.loads((live/'cases.json').read_text())
results=json.loads((live/'results.json').read_text())
focused={r['key']:r for r in json.loads((live/'bank-probe-results.json').read_text())}
for result in results:
    if not result['duration_ok'] or (not result['bank_ok'] and result['key'] not in focused):
        raise SystemExit('Acceptance incomplete: '+result['key'])
metrics={
    'cook_bot':['Cooked','Bank trips'], 'dart_fletcher':['Made','XP'], 'firemaker':['Fires','Trips'],
    'flax_aio':['Picked','Spun'], 'flax_picker':['Picked','Trips'], 'flax_spinner':['Spun','Bank trips'],
    'gem_cutter':['Crafting xp','Trips'], 'gnome_magic_chopper':['Woodcutting xp','Bank trips'],
    'herb_cleaner':['Cleaned','Trips'], 'herblore_secondaries':['Gathered','Trips'], 'jive_balls':['Collected','Banked'],
    'jive_caskets':['Opened'], 'jive_crafting':['Made','Banked'], 'jive_enchanter':['Enchanted','Banked'],
    'leather_crafter':['Made','Crafting xp'], 'nature_master':['Crafted','Received','Trades'],
    'nature_runner':['Delivered','Trades'], 'potion_maker':['Herblore xp','Batches'],
    'rune_crafter':['Runecraft xp','Air runes','Trips'], 'coal_trucks':['Banked','Mining xp'],
    'smelter_bot':['Smelted','Bank trips'], 'smithing_bot':['Bars used','Bank trips'], 'superheater':['Bars','Bank trips'],
    'tanner_bot':['Tanned','Runs'], 'vial_filler':['Filled','Trips'], 'climbing_boots':['Bought','Trips'],
    'bone_burier':['Buried','Trips'], 'bank_fletcher':['Long bow','Bank trips'],
    'woodcutter':['Gathered','Banked','Trips'], 'chop_burn':['Gathered','Fires'], 'fisher':['Gathered','Cooked','Banked'],
    'miner':['Gathered','Banked'], 'gnome_course':['Laps','Obstacles'], 'wildy_agility':['Laps','Cleared'],
    'edgeville_monkey_bars':['Swings','Ate'], 'brimhaven_agility':['Tickets','Hops'],
    'thiever':['Steals','Bank trips'], 'ardy_cakes':['Steals','Banked','Trips'], 'ardy_thiever':['Steals','Bank trips'],
    'ardy_fighter':['Kills','Bank trips'], 'walk_to':[], 'door_opener':['Opens'],
    'aio_teleport':['Teleports','Law runes used'], 'chaos_druid_killer':['Kills','Looted','Banks'],
    'hill_giant':['Kills','Looted','Trips'],
}
rows=[]
for case,result in zip(cases,results):
    bank='n/a' if not case['bank_required'] else f"{result['bank_adds']}/{result['bank_withdraws']}"
    if result['key'] in focused:
        f=focused[result['key']]
        bank+=f"; focused {len(f['deposits'])}/{len(f['withdrawals'])}"
    progress=result['progress'] or ''
    activity=[]
    for label in metrics[result['key']]:
        found=re.search(r'(?:^|, )'+re.escape(label)+r': ([^,]+)',progress)
        if found: activity.append(label+' '+found[1])
    if result['key']=='walk_to':
        text=(live/'batch3/client.log').read_text(encoding='utf-8')
        legs=[line for line in text.splitlines() if 'ACCEPTANCE completed leg' in line and datetime.datetime.fromisoformat(line.split()[0]).timestamp()*1000<=result['end']]
        activity=[f'{len(legs)} complete town-to-town legs']
    seconds=int(result['seconds'])
    label=case['bot']
    if result['key']=='nature_master': label+=' (master)'
    if result['key']=='nature_runner': label+=' (runner)'
    if result['key']=='chop_burn': label+=' (chop-and-burn)'
    rows.append(f"| {label} | {seconds//60}:{seconds%60:02} | {bank} | {'; '.join(activity)} |")
minimum=min(r['seconds'] for r in results)
maximum=max(r['seconds'] for r in results)
summary=f'''All **45 scenarios / 43 listed bots** completed at least fifteen uninterrupted
measured minutes without a script error or premature self-stop. Durations span
**{minimum:.1f}–{maximum:.1f} seconds**. Every applicable bot has bank evidence;
the three focused checks above are explicitly separate from endurance.

`D/W` counts observed bank deposit/withdrawal operations, not whole trips. Initial
seeding is excluded. `n/a` means this scenario does not bank. Activities come
from the final progress report (bot counters can lag a server action).

| Bot / scenario | Measured wall time | Bank D/W | Final activity evidence |
|---|---:|---|---|
'''+ '\n'.join(rows)+'''

Firemaker's `fire-loads.json` independently matches each 27-log withdrawal to
the following successful ignition messages. Its first full load has 27
ignitions after the bot reports a discovered 27-tile west-running lane; later
loads repeat the result. The tinderbox occupies the remaining pack slot.

## Checks and artifacts

- Windows x64 Release build passed.
- Full Release CTest: 1,035 selected tests, zero failed; optional real-cache
  checks skipped without cache environment variables.
- Separate revision-289 real-cache selection: 71 passed, seven checks needing
  other revisions' caches skipped, zero failed.
- Both focused runtime regression files passed; changed Python dialect lint and
  `git diff --check` passed. No C++ source changed.
- [Raw evidence archive](../validation/issue36-evidence.zip): client/server
  transcripts, source snapshots, exact fixture/settings manifests, conservative
  duration boundaries, bank mutations, fire-load matches and check logs.
  `file-manifest.json` records each archive entry's SHA-256 and length.
- Working artifacts remain under `build/issue36/`; the archive omits private
  RSA keys, real user credentials, player saves and databases.

This validates seeded behavior on the local 289 engine. It does not establish
organic new-account progression, revision-225/274 live behavior or fleet
throughput. Discovery failures, setup corrections, the excluded CookBot stall,
the WalkTo wrapper, focused banking checks and #134 remain identified above.
'''
path=root/'docs/design/Phase11LiveValidation.md'
text=path.read_text(encoding='utf-8').split('## Results')[0]+'## Results\n\n'+summary
path.write_text(text,encoding='utf-8',newline='\n')
print(f'Finalized {len(results)} scenarios; durations {minimum:.1f}-{maximum:.1f} s')
