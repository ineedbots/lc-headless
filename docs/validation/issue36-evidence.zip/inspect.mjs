import fs from 'node:fs';
const endpoints=await (await fetch('http://127.0.0.1:9236/json/list')).json();
const socket=new WebSocket(endpoints[0].webSocketDebuggerUrl);
await new Promise(resolve=>socket.addEventListener('open',resolve,{once:true}));
const result=new Promise(resolve=>socket.addEventListener('message',event=>{
    const response=JSON.parse(event.data);
    if(response.id===1) resolve(response);
}));
socket.send(JSON.stringify({id:1,method:'Runtime.evaluate',params:{expression:fs.readFileSync(process.argv[2],'utf8'),awaitPromise:true,returnByValue:true}}));
console.log(JSON.stringify(await result));
socket.close();
