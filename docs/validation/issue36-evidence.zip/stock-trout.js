(async()=>{
    const root='file:///C:/Users/NewBuilt/source/repos/runescape/289server/engine/src/';
    const {default:World}=await import(root+'engine/World.ts');
    const {default:InvType}=await import(root+'cache/config/InvType.ts');
    const p=[...World.players].find(p=>p?.username==='p36b44');
    if(!p) throw new Error('Missing scratch account');
    const n=p.invAdd(InvType.getId('bank'),333,2000);
    console.log('ISSUE36 FIXTURE_CORRECTION',JSON.stringify({at:Date.now(),account:p.username,id:333,count:n,reason:'HillGiant defaults to Trout; correction before restarting its measured run'}));
    return n;
})()
