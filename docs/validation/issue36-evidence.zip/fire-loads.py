import json
import pathlib

live=pathlib.Path(__file__).resolve().parent
loads=[]
for line in (live/'server.stdout.log').read_text(encoding='utf-8').splitlines():
    if not line.startswith('ISSUE36 '): continue
    _,kind,payload=line.split(' ',2)
    row=json.loads(payload)
    if row.get('account')!='p36b02': continue
    if kind=='BANK' and row['method']=='invDel' and row['id']==1511:
        loads.append(dict(withdraw_at=row['at'],loaded=row['count'],ignitions=[]))
    if kind=='MESSAGE' and 'The fire catches and the logs begin to burn.' in row['text'] and loads:
        loads[-1]['ignitions'].append(dict(at=row['at'],tile=row['tile']))
(live/'fire-loads.json').write_text(json.dumps(loads,indent=2)+'\n')
print([(load['loaded'],len(load['ignitions'])) for load in loads])
