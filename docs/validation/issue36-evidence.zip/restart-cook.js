(()=>{
    const world=globalThis.issue36World;
    const p=[...world.players].find(p=>p?.username==='p36b00');
    if(!p) throw new Error('Missing scratch CookBot');
    console.log('ISSUE36 FIXTURE_CORRECTION',JSON.stringify({at:Date.now(),account:p.username,tile:[p.x,p.z,p.level],reason:'Restart with random-event guardian enabled; previous interval stalled after server relocation'}));
    world.removePlayer(p);
    return true;
})()
