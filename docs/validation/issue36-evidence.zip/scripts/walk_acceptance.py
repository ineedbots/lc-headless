from bots.walk_to import SETTINGS, WalkToBot


class WalkAcceptance(WalkToBot):
    def on_start(self):
        WalkToBot.on_start(self)
        self.bind_finish(self.next_destination)
        self.legs = 0

    def next_destination(self, reason):
        if not reason.startswith('WalkTo: arrived at'):
            raise RuntimeError(reason)
        self.legs += 1
        self.log(f'ACCEPTANCE completed leg {self.legs}: {reason}')
        settings_store.save('WalkTo', 'destination', 'Varrock' if self.destination == 'Falador' else 'Falador')


BOT = define_bot(name='WalkTo', create=WalkAcceptance, settings_schema=SETTINGS)
