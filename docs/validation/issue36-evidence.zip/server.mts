import { pathToFileURL } from 'node:url';
import fs from 'node:fs';
const engine = process.argv[2].replaceAll('\\', '/');
const url = (name: string) => pathToFileURL(`${engine}/src/${name}`).href;
await import(url('app.ts'));
const { default: World } = await import(url('engine/World.ts'));
const { PlayerLoading } = await import(url('engine/entity/PlayerLoading.ts'));
const { default: Player } = await import(url('engine/entity/Player.ts'));
const { default: VarPlayerType } = await import(url('cache/config/VarPlayerType.ts'));
const { default: InvType } = await import(url('cache/config/InvType.ts'));
const { default: ObjType } = await import(url('cache/config/ObjType.ts'));
const cases = JSON.parse(fs.readFileSync('../cases.json','utf8'));
const seeds = new Map(cases.map((c: any)=>[c.username,c]));
const record = (kind: string, data: any) => console.log('ISSUE36',kind,JSON.stringify({at:Date.now(),tick:World.currentTick,...data}));
const resolve = (name: any) => {
    if (typeof name === 'number') return name;
    const found = ObjType.configs.find((o:any)=>o?.name?.toLowerCase()===name.toLowerCase() && o.certtemplate===-1);
    if (!found) throw new Error('Unknown seed item '+name);
    return found.id;
};
const load = PlayerLoading.load;
PlayerLoading.load = function(...args: any[]) {
    const p = load.apply(this,args);
    const seed: any = seeds.get(p.username);
    if (!seed || args[1].data.length>=2) return p;
    for(const name of ['inv','worn','bank']) {
        p.invClear(InvType.getId(name));
    }
    const vars = {tutorial:1000,druidquest:4,runemysteries:6,zanaris:6,qp:100,...seed.vars};
    for(const [name,value] of Object.entries(vars)) {
        const id=VarPlayerType.getId(name);
        if(id<0) throw new Error('Unknown seed var '+name);
        p.vars[id]=value;
    }
    for(let stat=0;stat<p.stats.length;stat++) p.setLevel(stat,85);
    [p.x,p.z,p.level]=seed.tile;
    for(const container of ['bank','pack']) for(const [name,count] of seed[container]) {
        const id=resolve(name), inv=InvType.getId(container==='pack'?'inv':'bank');
        if(p.invAdd(inv,id,count)!==count) throw new Error('Seed inventory failed '+name);
    }
    for(const [slot,id] of seed.worn) p.invSet(InvType.getId('worn'),id,1,slot);
    record('SEED',{account:p.username,seed,vars,levels:[...p.levels],tickRate:World.tickRate});
    return p;
};
for(const method of ['invAdd','invDel']) {
    const original=Player.prototype[method];
    Player.prototype[method]=function(inv:number,obj:number,count:number,...args:any[]) {
        const result=original.call(this,inv,obj,count,...args);
        if(seeds.has(this.username) && inv===InvType.getId('bank') && result>0) record('BANK',{account:this.username,method,id:obj,name:ObjType.get(obj).name,count:result,tile:[this.x,this.z,this.level]});
        return result;
    };
}
const message=Player.prototype.messageGame;
Player.prototype.messageGame=function(text:string,...args:any[]) {
    if(seeds.has(this.username)) record('MESSAGE',{account:this.username,text,tile:[this.x,this.z,this.level]});
    return message.call(this,text,...args);
};
setInterval(()=>{
    for(const p of World.players) {
        if(!p || !seeds.has(p.username)) continue;
        record('SAMPLE',{account:p.username,tile:[p.x,p.z,p.level],xp:[...p.stats],containers:Object.fromEntries(['inv','worn','bank'].map(name=>[name,p.getInventory(InvType.getId(name))?.items.filter(Boolean)]))});
    }
},30000);
if(World.tickRate!==600) throw new Error('Expected 600 ms ticks');
record('READY',{tickRate:World.tickRate,cases:cases.length});
